﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(BloodDonationWeb.Startup))]
namespace BloodDonationWeb
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
